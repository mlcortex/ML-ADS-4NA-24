// Seleciona o botão e o container onde o link será exibido
const generateLinkButton = document.getElementById('generate-link');
const linkContainer = document.getElementById('link-container');

// Função para gerar o link local
function generateLocalLink() {
    // Caminho relativo ao arquivo aluno.html
    const localLink = '../aluno/aluno.html';

    // Limpa o container e insere o novo link
    linkContainer.innerHTML = `
        <p>Seu link foi gerado com sucesso:</p>
        <a href="${localLink}" class="generated-link" target="_blank">Acessar Aluno</a>
    `;
}

// Adiciona o evento de clique no botão
generateLinkButton.addEventListener('click', generateLocalLink);
